import numpy as np
import sys
sys.path.append("/usr/local/lib/python3.10/site-packages/")
from pathlib import Path
import cv2
from sss.utils.kalibr import load_kalibr
from apriltag import apriltag
from scipy.spatial.transform import Rotation as R
import tqdm



def undistort(image, intrinsics, distortion_parameters, new_intrinsics=None):
    image_undistorted = cv2.undistort(image, intrinsics, distortion_parameters, None, new_intrinsics)
    return image_undistorted

def detect_april_tags(image):
    # tagStandard41h12
    detector = apriltag("tagStandard41h12")
    detections = detector.detect(image)
    return detections


def path_to_us(f: Path):
    # they are in nanoseconds
    return int(f.name.split(".")[0]) / 1e3

def april_tag_id_to_3d_points(id, width=0.01):
    # order of 2D points: lb-rb-rt-lt
    # convention
    #  (0,0,0)  ---> x
    # |  lt--------rt     ---------
    # |  |         |     |         |
    # v  |    0    |     |   1     |
    # y  lb--------rb     ---------
    #
    #     ---------       ---------
    #    |    2    |     |    3    |
    #    |         |     |         |
    #     ---------       ---------

    lt_offsets = np.array([[0, width],
                  [width, width],
                  [width, 0],
                  [0, 0]])

    idx_offset = np.array([[0, 0],
                  [2*width, 0],
                  [0, 2*width],
                  [2*width, 2*width]])

    xy = idx_offset[id] + lt_offsets
    xyz = np.concatenate((xy, np.zeros_like(xy[:,:1])), axis=1)

    return xyz


def draw_on_image(image, results):
    image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    for r in results:
        # extract the bounding box (x, y)-coordinates for the AprilTag
        # and convert each of the (x, y)-coordinate pairs to integers
        (ptA, ptB, ptC, ptD) = r["lb-rb-rt-lt"]
        ptB = (int(ptB[0]), int(ptB[1]))
        ptC = (int(ptC[0]), int(ptC[1]))
        ptD = (int(ptD[0]), int(ptD[1]))
        ptA = (int(ptA[0]), int(ptA[1]))
        # draw the bounding box of the AprilTag detection
        cv2.line(image, ptA, ptB, (0, 255, 0), 2)
        cv2.line(image, ptB, ptC, (0, 255, 0), 2)
        cv2.line(image, ptC, ptD, (0, 255, 0), 2)
        cv2.line(image, ptD, ptA, (0, 255, 0), 2)
        # draw the center (x, y)-coordinates of the AprilTag
        (cX, cY) = (int(r["center"][0]), int(r["center"][1]))
        cv2.circle(image, (cX, cY), 5, (0, 0, 255), -1)
        # draw the tag family on the image
        tagFamily = str(r['id'])#.tag_family.decode("utf-8")

        cv2.putText(image, tagFamily, (ptA[0], ptA[1] - 15),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        points_3d = april_tag_id_to_3d_points(r['id'])
        for (x,y,z), (x_px, y_px) in zip(points_3d, r['lb-rb-rt-lt']):
            cv2.putText(image, str((x,y)), (int(x_px), int(y_px) - 1),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)


    return image

def compute_camera_pose(detections, points_3d, camera_matrix):
    ret, rvecs, tvecs = cv2.solvePnP(points_3d, detections, camera_matrix, (0,0,0,0), flags=cv2.SOLVEPNP_ITERATIVE)

    T = np.eye(4)
    T[:3, :3] = rodrigues(rvecs[:,0])
    T[:3,  3] = tvecs[:,0]

    return T, ret


def rodrigues(k):
    # Ensure k is a unit vector
    theta = np.linalg.norm(k)
    if theta < 1e-10:
        return np.eye(3)

    k = k / theta
    kx, ky, kz = k

    # Skew-symmetric matrix K
    K = np.array([
        [0, -kz, ky],
        [kz, 0, -kx],
        [-ky, kx, 0]
    ])

    # Identity matrix
    I = np.eye(3)

    # Rodrigues' rotation matrix
    R = I + np.sin(theta) * K + (1 - np.cos(theta)) * K @ K

    return R

def store_trajectory_in_tum_format(timestamps_us, poses, output_path):
    timestamps_s = timestamps_us / 1e6
    quaternions = R.from_matrix(poses[:,:3,:3]).as_quat()
    translations = poses[:,:3,3]

    tum_output = np.concatenate((timestamps_s[:,None], translations, quaternions), axis=1)

    np.savetxt(output_path, tum_output)

def parse_results(results):
    pixels = np.concatenate([r["lb-rb-rt-lt"] for r in results])
    points_3d = np.concatenate([april_tag_id_to_3d_points(r['id']) for r in results])
    return pixels, points_3d


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser("""""")
    parser.add_argument("--images_folder", type=Path)
    parser.add_argument("--calibration_file", type=Path)
    parser.add_argument("--detections_path", type=Path)
    parser.add_argument("--output_path", type=Path)
    parser.add_argument("--debug_folder", type=Path)
    args = parser.parse_args()

    path = args.images_folder
    calibration_file = args.calibration_file

    kalibr = load_kalibr(calibration_file)
    new_intrinsics, roi = cv2.getOptimalNewCameraMatrix(kalibr['cam0']['K'],
                                                        kalibr['cam0']['distortion_coeffs'],
                                                        kalibr['cam0']['resolution'],
                                                        1, kalibr['cam0']['resolution'])


    images_paths = sorted(list(path.glob("*.png")))
    timestamps = np.array([path_to_us(f) for f in images_paths])
    images = [cv2.imread(str(f), cv2.IMREAD_GRAYSCALE) for f in images_paths]

    poses = []
    timestamps_filtered = []
    detections = []
    points_3d = []

    write_to_debug_folder = args.debug_folder is not None
    if write_to_debug_folder:
        args.debug_folder.mkdir(exist_ok=True, parents=True)

    for j, image in enumerate(tqdm.tqdm(images)):
        image = undistort(image, kalibr['cam0']['K'], kalibr['cam0']['distortion_coeffs'], new_intrinsics)
        results = detect_april_tags(image)

        if len(results) == 0:
            continue

        det, landmarks = parse_results(results)
        camera_pose, success = compute_camera_pose(det, landmarks, new_intrinsics)

        detections.append(det)
        points_3d.append(landmarks)

        if not success:
            print("No success")
            continue

        #print(camera_pose)
        if write_to_debug_folder:
            image_drawn = draw_on_image(image, results)
            cv2.imwrite(str(args.debug_folder / f"{j:05d}.jpg"), image_drawn)
            cv2.imshow("image", image_drawn)
            cv2.waitKey(1)

        timestamps_filtered.append(timestamps[j])
        poses.append(camera_pose)

    timestamps_filtered = np.array(timestamps_filtered)
    poses = np.stack(poses, axis=0)

    timestamps_detections = np.concatenate([np.full(shape=(len(d),), fill_value=t) for d, t in zip(detections, timestamps_filtered)])
    detections = np.concatenate(detections)
    points_3d = np.concatenate(points_3d)
    detection_data = np.concatenate((timestamps_detections.reshape((-1,1)), detections, points_3d), axis=-1)
    np.save(str(args.detections_path), detection_data)

    if args.output_path is not None:
        store_trajectory_in_tum_format(timestamps_filtered, poses, args.output_path)


